package com.trafficsign.activity;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.trafficsign.activity.R;
import com.trafficsign.json.CategoryJSON;
import com.trafficsign.json.TrafficInfoShortJSON;
import com.trafficsign.ultils.ConvertUtil;
import com.trafficsign.ultils.HttpUtil;
import com.trafficsign.ultils.MyInterface.IAsyncHttpListener;
import com.trafficsign.ultils.Properties;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;
import static com.trafficsign.ultils.Properties.serviceIp;

public class CategoryActivity extends Activity {

	ArrayList<CategoryJSON> listCategory = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category);
		Intent intent = getIntent();
		try {
			listCategory = (ArrayList<CategoryJSON>) ConvertUtil
					.bytes2Object(intent.getByteArrayExtra("catList"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final ListView lv = (ListView) findViewById(R.id.listCategory);
		ListCategoryArrayAdapter myArray = new ListCategoryArrayAdapter(this,
				R.layout.list_rowcat, listCategory);
		lv.setAdapter(myArray);
		//
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				CategoryJSON categoryJSON = listCategory.get(position);
				// parse json array
				String url = serviceIp + Properties.TRAFFIC_SEARCH_MANUAL
						+ "?name=&cateID=" + categoryJSON.getCategoryID();
				HttpUtil httpUtil = new HttpUtil(CategoryActivity.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						// get data from json array to list
						ArrayList<TrafficInfoShortJSON> listTrafficInfo = new ArrayList<TrafficInfoShortJSON>();
						Gson gson = new Gson();
						Type type = new TypeToken<ArrayList<TrafficInfoShortJSON>>() {
						}.getType();
						listTrafficInfo = gson.fromJson(response, type);

						try {
							Intent nextScreen = new Intent(
									getApplicationContext(),
									ListTrafficSignActivity.class);
							byte[] dataBytes = ConvertUtil
									.object2Bytes(listTrafficInfo);
							nextScreen.putExtra("trafficList", dataBytes);
							nextScreen
									.putExtra("catName", "Danh Sách Biển Báo");
							startActivity(nextScreen);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}// end onComplete
				});
				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
		//
		ImageButton btnSearch = (ImageButton) findViewById(R.id.searchButton);
		btnSearch.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View V) {
				// TODO Auto-generated method stub
				// parse json array
				EditText searchKey = (EditText) findViewById(R.id.searchTraffic);
				String keyWord = searchKey.getText().toString();
				String url;

				HttpUtil httpUtil = new HttpUtil(CategoryActivity.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						ArrayList<TrafficInfoShortJSON> listTrafficInfo = new ArrayList<TrafficInfoShortJSON>();
						Gson gson = new Gson();
						Type type = new TypeToken<ArrayList<TrafficInfoShortJSON>>() {
						}.getType();
						listTrafficInfo = gson.fromJson(response, type);

						try {
							Intent nextScreen = new Intent(
									getApplicationContext(),
									ListTrafficSignActivity.class);
							byte[] dataBytes = ConvertUtil
									.object2Bytes(listTrafficInfo);
							nextScreen.putExtra("trafficList", dataBytes);
							nextScreen.putExtra("catName", "Kết quả tìm kiếm");
							startActivity(nextScreen);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				});
				try {
					url = serviceIp + Properties.TRAFFIC_SEARCH_MANUAL
							+ "?name=" + URLEncoder.encode(keyWord, "UTF-8");
					httpUtil.setUrl(url);
					httpUtil.execute();
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// TODO Auto-generated method stub
	}
}
