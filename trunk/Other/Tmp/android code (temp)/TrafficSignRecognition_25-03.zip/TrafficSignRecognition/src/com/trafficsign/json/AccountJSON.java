package com.trafficsign.json;

public class AccountJSON {

}
