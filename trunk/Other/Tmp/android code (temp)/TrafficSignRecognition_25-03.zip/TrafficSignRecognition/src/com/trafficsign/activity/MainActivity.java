package com.trafficsign.activity;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;

import static com.trafficsign.ultils.Properties.serviceIp;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.trafficsign.ultils.Properties;
import com.trafficsign.activity.R;
import com.trafficsign.json.CategoryJSON;
import com.trafficsign.ultils.ConvertUtil;
import com.trafficsign.ultils.HttpUtil;
import com.trafficsign.ultils.JSONArrayParser;
import com.trafficsign.ultils.MyInterface.IAsyncHttpListener;
//import com.example.ultils.MyInterface.IAsyncFetchListener;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// init resource
		String externalPath = Environment.getExternalStorageDirectory()
				.getPath() + "/";
		Properties.APP_FOLDER = externalPath + Properties.APP_FOLDER;
		File appFolder = new File(Properties.APP_FOLDER);
		if (!appFolder.exists()) {
			appFolder.mkdir();
		}
		File imageFolder = new File(Properties.APP_FOLDER
				+ Properties.IMAGE_FOLDER);
		if (!imageFolder.exists()) {
			imageFolder.mkdir();
		}
		// set event for manual search button
		ImageButton imgBtnManualSearch = (ImageButton) findViewById(R.id.imageButtonManualSearch);

		imgBtnManualSearch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// parse json array
				String url = serviceIp + Properties.TRAFFIC_LIST_CATEGORY;
				HttpUtil httpUtil = new HttpUtil(MainActivity.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String respond) {
						ArrayList<CategoryJSON> listCategory = new ArrayList<CategoryJSON>();
						Gson gson = new Gson();
						Type type = new TypeToken<ArrayList<CategoryJSON>>() {
						}.getType();
						listCategory = gson.fromJson(respond, type);
											
						try {
							Intent nextScreen = new Intent(
									getApplicationContext(),
									CategoryActivity.class);
							byte[] dataBytes = ConvertUtil.object2Bytes(listCategory);
							nextScreen.putExtra("catList", dataBytes);
							startActivity(nextScreen);
						}  catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
		// set event onclick for auto search button
		final ImageButton imgBtnAutoSearch = (ImageButton) findViewById(R.id.imageButtonAutoSearch);
		imgBtnAutoSearch.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent nextScreen = new Intent(getApplicationContext(),
						CameraActivity.class);
				startActivity(nextScreen);

			}
		});
		// set event onclick for auto search button
		ImageButton imgBtnHistory = (ImageButton) findViewById(R.id.imageButtonHistory);
		imgBtnHistory.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent nextScreen = new Intent(getApplicationContext(),
						ListResultActivity.class);
				startActivity(nextScreen);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
