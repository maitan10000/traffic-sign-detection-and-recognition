package com.trafficsign.activity;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.trafficsign.activity.R;
import com.trafficsign.json.TrafficInfoJSON;
import com.trafficsign.json.TrafficInfoShortJSON;
import com.trafficsign.ultils.ConvertUtil;
import com.trafficsign.ultils.HttpUtil;
import com.trafficsign.ultils.MyInterface.IAsyncHttpListener;
import com.trafficsign.ultils.Properties;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;
import static com.trafficsign.ultils.Properties.serviceIp;

public class ListTrafficSignActivity extends Activity {

	ListTrafficArrayAdapter myArray;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO Auto-generated method stub
		Intent intent = getIntent();
		this.setTitle(intent.getStringExtra("catName"));
		setContentView(R.layout.activity_listtraffic);
		System.out.println("vao dc activity moi");

		ArrayList<TrafficInfoShortJSON> listTrafficInfo = null;
		try {
			listTrafficInfo = (ArrayList<TrafficInfoShortJSON>) ConvertUtil.bytes2Object(intent
					.getByteArrayExtra("trafficList"));
			if(listTrafficInfo == null){
				listTrafficInfo = new ArrayList<TrafficInfoShortJSON>();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*********************/
		final ListView lv = (ListView) findViewById(R.id.listTraffic);
		myArray = new ListTrafficArrayAdapter(this, R.layout.list_row, listTrafficInfo);
		lv.setAdapter(myArray);
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				View temView2 = myArray.getView(position, null, lv);
				TextView trafficName = (TextView) temView2
						.findViewById(R.id.trafficName);
				TextView trafficID = (TextView) temView2
						.findViewById(R.id.trafficID);

				// get detail from server
				String url = serviceIp +Properties.TRAFFIC_TRAFFIC_VIEW +"?id=" + trafficID.getText();
				// System.out.println("url ne : " + url);
				HttpUtil httpUtil = new HttpUtil();
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						
						TrafficInfoJSON trafficInfoJSON =  new TrafficInfoJSON();
						Gson gson = new Gson();
						trafficInfoJSON = gson.fromJson(response, TrafficInfoJSON.class);
						try {
							// move next screen
							Intent nextScreen = new Intent(
									getApplicationContext(),
									TracfficSignDetailActivity.class);
							try {
								byte[] dataBytes = ConvertUtil
										.object2Bytes(trafficInfoJSON);
								nextScreen
										.putExtra("trafficDetails", dataBytes);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							startActivity(nextScreen);

						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}// end onComplete
				});
				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
	}

}
