package com.example.ultils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;

import com.example.trafficsignrecognition.MainActivity;
import com.example.ultils.MyInterface.IAsyncHttpListener;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

public class HttpUtil extends AsyncTask<Void, Void, Void> {
	private IAsyncHttpListener httpListener = null;
	private Context context;
	private ProgressDialog dialog;
	private String respond = "";

	private String method = "GET";
	private List<NameValuePair> parameters;
	private String url = "";

	public HttpUtil(Context ctx){
		this.context = ctx;
		dialog = new ProgressDialog(this.context);
	}
	public HttpUtil(){
		
	}
	public IAsyncHttpListener getHttpListener() {
		return httpListener;
	}

	public void setHttpListener(IAsyncHttpListener httpListener) {
		this.httpListener = httpListener;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public List<NameValuePair> getParameters() {
		return parameters;
	}

	public void setParameters(List<NameValuePair> parameters) {
		this.parameters = parameters;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	protected Void doInBackground(Void... params) {
		// TODO Auto-generated method stub
		respond = "";
		try {
			// create client
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpResponse httpResponse;
			if (this.method.toUpperCase().equals("GET")) {
				HttpGet request = new HttpGet(url);
				httpResponse = httpClient.execute(request);
			} else {
				HttpPost request = new HttpPost(url);
				request.setEntity(new UrlEncodedFormEntity(parameters, "UTF-8"));
				httpResponse = httpClient.execute(request);
			}

			// Begin get respond
			HttpEntity httpEntity = httpResponse.getEntity();
			InputStream is = httpEntity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "UTF-8"), 8);
			String line = null;
			while ((line = reader.readLine()) != null) {
				respond += line;
			}
			is.close();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	@Override
    protected void onPreExecute() {
		if(dialog!=null){
			dialog.setMessage("Loading");
			dialog.setCancelable(false);
			dialog.show();
		}
		
    }

	@Override
	protected void onPostExecute(Void params) {
		// TODO Auto-generated method stub
		// super.onPostExecute(result);
		if (this.httpListener != null) {
			this.httpListener.onComplete(this.respond);
			if(dialog != null){
				dialog.dismiss();
			}
		}
	}
}
