package com.example.trafficsignrecognition;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import static com.example.ultils.Properties.serviceIp;
import org.json.JSONArray;
import org.json.JSONException;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.objdetect.Objdetect;
import org.opencv.core.*;

import vo.ResultInput;

import com.example.ultils.ConvertUtil;
import com.example.ultils.UploadUtils;
import com.example.view.CameraView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.hardware.Camera.Size;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnTouchListener;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import static com.example.ultils.Properties.*;

public class CameraActivity extends Activity implements CvCameraViewListener2,
		OnTouchListener {
	private int count = 0;
	private boolean isAuto = false;
	private boolean flag = false;
	private String jsonString = "";
	private static final String TAG = "OpenCVDemo::Activity";
	private CameraView mOpenCvCameraView;
	private List<Size> mResolutionList;
	private MenuItem[] mResolutionMenuItems;
	private SubMenu mResolutionMenu;
	private CascadeClassifier warningDetector = null;
	private int blinkCount = 0;
	private ImageButton btnTakeImage;

	private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
		@Override
		public void onManagerConnected(int status) {
			switch (status) {
			case LoaderCallbackInterface.SUCCESS: {
				Log.i(TAG, "OpenCV loaded successfully");
				mOpenCvCameraView.enableView();
				mOpenCvCameraView.setOnTouchListener(CameraActivity.this);
			}
				break;
			default: {
				super.onManagerConnected(status);
			}
				break;
			}
		}

	};

	String fileName = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_camera);
		
		//
		mOpenCvCameraView = (CameraView) findViewById(R.id.cameraVIew);
		mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
		mOpenCvCameraView.setCvCameraViewListener(this);
		Log.i(TAG, "Create successully");

		btnTakeImage = (ImageButton) findViewById(R.id.take);
		btnTakeImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd_HH-mm-ss");
				String currentDateandTime = sdf.format(new Date());
				fileName = Environment.getExternalStorageDirectory().getPath()
						+ "/sample_picture_" + currentDateandTime + ".jpg";
				// ProgressDialog dialog = new
				// ProgressDialog(CameraActivity.this);
				// dialog.setMessage("Loading..");
				// dialog.setCancelable(false);
				// dialog.show();
				mOpenCvCameraView.takePicture(fileName);
				Toast.makeText(getApplicationContext(), fileName + " saved",
						Toast.LENGTH_SHORT).show();
				isTaken = true;
				// testing upload file ****************************
				final String upLoadServerUri = serviceIp + "upload";

				// dialog = ProgressDialog.show(UploadToServer.this, "",
				// "Uploading file...", true);

				new Thread(new Runnable() {
					volatile boolean running = true;

					public void run() {
						runOnUiThread(new Runnable() {
							public void run() {
								// ProgressDialog dialog = new
								// ProgressDialog(CameraActivity.this);
								// dialog.setMessage("Loading..");
								// dialog.setCancelable(false);
								// dialog.show();
								// if(!running){
								// dialog.dismiss();
								// }
							}
						});
						try {

							Thread.sleep(2000);
							// Resize
							Size cameraSize = mOpenCvCameraView.getResolution();
							org.opencv.core.Size size = new org.opencv.core.Size();
							size.height = cameraSize.height;
							size.width = cameraSize.width;

							Mat tmpImage = Highgui.imread(fileName);
							Mat tmpResize = new Mat(size, tmpImage.type());
							Imgproc.resize(tmpImage, tmpResize,
									tmpResize.size());
							Highgui.imwrite(fileName, tmpResize);
							// end resize
							// jsonString = "";
							jsonString = UploadUtils.uploadFile(fileName,
									upLoadServerUri);
							/* parse json */
							try {
								if (jsonString.contains("Error")) {
									runOnUiThread(new Runnable() {
										public void run() {
											Toast.makeText(
													getApplicationContext(),
													jsonString,
													Toast.LENGTH_LONG).show();
										}
									});

								} else {
									isTaken = false;
									Log.i(TAG, "JsonString: " + jsonString);
									JSONArray jsonArr = new JSONArray(
											jsonString);
									ArrayList<ResultInput> resultInput = new ArrayList<ResultInput>();
									resultInput = ConvertUtil
											.parseToList(jsonArr);
									System.out.println("chieu dai mang ne :"
											+ resultInput.size());

									if (resultInput.size() == 0) {
										runOnUiThread(new Runnable() {
											public void run() {
												Toast.makeText(
														getApplicationContext(),
														"Khong co kq",
														Toast.LENGTH_LONG)
														.show();
											}
										});
									}
									// create intent
									Intent nextScreen = new Intent(
											getApplicationContext(),
											ListResult.class);
									nextScreen.putExtra("imagePath", fileName);
									/* put resultInput to the next screen */
									byte[] dataBytes;
									try {
										dataBytes = ConvertUtil
												.object2Bytes(resultInput);
										System.out
												.println("Convert thanh cong");
										nextScreen.putExtra("listResult",
												dataBytes);
										System.out.println("Put thanh cong");
										startActivity(nextScreen);
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}

								/* end put */
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}).start();
			}
		});
		// end test upload file **************************************

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.camera_menu, menu);

		// mResolutionMenu = menu.addSubMenu("Resolution");
		// mResolutionMenu = menu.addSubMenu("Chế độ chụp");
		// mResolutionList = mOpenCvCameraView.getResolutionList();
		// mResolutionMenuItems = new MenuItem[mResolutionList.size()];
		//
		// ListIterator<Size> resolutionItr = mResolutionList.listIterator();
		// int idx = 0;
		// while (resolutionItr.hasNext()) {
		// Size element = resolutionItr.next();
		// mResolutionMenuItems[idx] = mResolutionMenu.add(1, idx, Menu.NONE,
		// Integer.valueOf(element.width).toString() + "x"
		// + Integer.valueOf(element.height).toString());
		// idx++;
		// }

		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		// Log.i(TAG, "called onOptionsItemSelected; selected item: " + item);
		// if (item.getGroupId() == 1) {
		// int id = item.getItemId();
		// Size resolution = mResolutionList.get(id);
		// mOpenCvCameraView.setResolution(resolution);
		// resolution = mOpenCvCameraView.getResolution();
		// String caption = Integer.valueOf(resolution.width).toString() + "x"
		// + Integer.valueOf(resolution.height).toString();
		// Toast.makeText(this, caption, Toast.LENGTH_SHORT).show();
		// }
		switch (item.getItemId()) {
		case R.id.byHand: {
			isAuto = false;
			item.setChecked(true);

		}
		case R.id.auto: {
			isAuto = true;
			item.setChecked(true);

		}
		}
		return true;
	}

	@SuppressLint("SimpleDateFormat")
	@Override
	public boolean onTouch(View arg0, MotionEvent arg1) {
		// TODO Auto-generated method stub
		// Take picture
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		// String currentDateandTime = sdf.format(new Date());
		// String fileName = Environment.getExternalStorageDirectory().getPath()
		// + "/sample_picture_" + currentDateandTime + ".jpg";
		// mOpenCvCameraView.takePicture(fileName);
		// Toast.makeText(this, fileName + " saved", Toast.LENGTH_SHORT).show();
		return false;
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mOpenCvCameraView != null)
			mOpenCvCameraView.disableView();
	}

	@Override
	public void onResume() {
		super.onResume();
		OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_3, this,
				mLoaderCallback);
	}

	public void onDestroy() {
		super.onDestroy();
		if (mOpenCvCameraView != null)
			mOpenCvCameraView.disableView();
	}

	@Override
	public void onCameraViewStarted(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onCameraViewStopped() {
		// TODO Auto-generated method stub

	}

	Mat frame;

	@Override
	public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
		// TODO Auto-generated method stub
		if (isTaken == false) {
			frame = inputFrame.rgba();
		} else {
			frame = Highgui.imread(fileName, Highgui.CV_LOAD_IMAGE_COLOR);
		}
		if (frame.empty()) {
			Log.e(TAG, "Failed to load image");
		}

		// Detect traffic sign
		if (warningDetector == null || warningDetector.empty()) {
			// Init cascade to detect
			InputStream is = getResources()
					.openRawResource(R.raw.cascade_type1);
			File cascadeDir = getDir("cascade", Context.MODE_PRIVATE);
			File mCascadeFile = new File(cascadeDir, "cascade_type1.xml");
			try {
				FileOutputStream os = new FileOutputStream(mCascadeFile);
				byte[] buffer = new byte[4096];
				int bytesRead;
				while ((bytesRead = is.read(buffer)) != -1) {
					os.write(buffer, 0, bytesRead);
				}
				is.close();
				os.close();

				warningDetector = new CascadeClassifier(
						mCascadeFile.getAbsolutePath());
				if (warningDetector != null) {
					Log.i(TAG, "Load cascade successfully");
				}

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			// Log.i(TAG, "Loaded cascade classifier from ");
			MatOfRect results = new MatOfRect();
			org.opencv.core.Size minSize = new org.opencv.core.Size();
			minSize.height = 20;
			minSize.width = 20;

			org.opencv.core.Size maxSize = new org.opencv.core.Size();
			maxSize.height = 250;
			maxSize.width = 250;
			// Mat frame_gray = frame.clone();
			// Imgproc.cvtColor(frame, frame_gray, 6);
			// Imgproc.equalizeHist(frame_gray, frame_gray);
			warningDetector.detectMultiScale(frame, results, 1.1, 1, 0 | 2,
					minSize, maxSize);

			Rect[] resultArray = results.toArray();
			for (int i = 0; i < resultArray.length; i++)
				Core.rectangle(frame, resultArray[i].tl(), resultArray[i].br(),
						new Scalar(204, 51, 204), 3);
			// test take picture auto
			count++;
			if (resultArray.length > 0 && count > 20 && isTaken == false
					&& isAuto == true) {
				count = 0;
				// flag = true;
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd_HH-mm-ss");
				String currentDateandTime = sdf.format(new Date());
				final String fileName = Environment
						.getExternalStorageDirectory().getPath()
						+ "/sample_picture_" + currentDateandTime + ".jpg";

				mOpenCvCameraView.takePicture(fileName);
				isTaken = true;
				final String upLoadServerUri = serviceIp + "upload";
				new Thread(new Runnable() {
					volatile boolean running = true;

					public void run() {
						runOnUiThread(new Runnable() {
							public void run() {
								// ProgressDialog dialog = new
								// ProgressDialog(CameraActivity.this);
								// dialog.setMessage("Loading..");
								// dialog.setCancelable(false);
								// dialog.show();
								// if(!running){
								// dialog.dismiss();
								// }
							}
						});
						try {

							Thread.sleep(2000);
							// Resize
							Size cameraSize = mOpenCvCameraView.getResolution();
							org.opencv.core.Size size = new org.opencv.core.Size();
							size.height = cameraSize.height;
							size.width = cameraSize.width;

							Mat tmpImage = Highgui.imread(fileName);
							Mat tmpResize = new Mat(size, tmpImage.type());
							Imgproc.resize(tmpImage, tmpResize,
									tmpResize.size());
							Highgui.imwrite(fileName, tmpResize);
							// end resize
							// jsonString = "";
							jsonString = UploadUtils.uploadFile(fileName,
									upLoadServerUri);
							/* parse json */
							try {
								if (jsonString.contains("Error")) {
									runOnUiThread(new Runnable() {
										public void run() {
											Toast.makeText(
													getApplicationContext(),
													jsonString,
													Toast.LENGTH_LONG).show();
										}
									});

								} else {
									isTaken = false;
									Log.i(TAG, "JsonString: " + jsonString);
									JSONArray jsonArr = new JSONArray(
											jsonString);
									ArrayList<ResultInput> resultInput = new ArrayList<ResultInput>();
									resultInput = ConvertUtil
											.parseToList(jsonArr);
									System.out.println("chieu dai mang ne :"
											+ resultInput.size());

									if (resultInput.size() == 0) {
										runOnUiThread(new Runnable() {
											public void run() {
												Toast.makeText(
														getApplicationContext(),
														"Khong co kq",
														Toast.LENGTH_LONG)
														.show();
											}
										});
									}
									// create intent
									Intent nextScreen = new Intent(
											getApplicationContext(),
											ListResult.class);
									nextScreen.putExtra("imagePath", fileName);
									/* put resultInput to the next screen */
									byte[] dataBytes;
									try {
										dataBytes = ConvertUtil
												.object2Bytes(resultInput);
										System.out
												.println("Convert thanh cong");
										nextScreen.putExtra("listResult",
												dataBytes);
										System.out.println("Put thanh cong");
										startActivity(nextScreen);
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}

								/* end put */
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}).start();

			}
		}

		// Hint to help user capture image
		if (blinkCount == 0) {
			int width = frame.width();
			int height = frame.height();

			Rect hintRect = new Rect();
			hintRect.height = 100;
			hintRect.width = 100;
			hintRect.y = (height - hintRect.height) / 2;
			hintRect.x = (width - hintRect.width) / 2;
			Core.rectangle(frame, hintRect.tl(), hintRect.br(), new Scalar(255,
					255, 255), 2);
			blinkCount = 2;
		} else {
			blinkCount--;
		}
		return frame;

	}
}
