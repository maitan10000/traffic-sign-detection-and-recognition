package com.example.trafficsignrecognition;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.example.ultils.ConvertUtil;
import com.example.ultils.HttpUtil;
import com.example.ultils.MyInterface.IAsyncHttpListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;
import static com.example.ultils.Properties.serviceIp;

public class ListTrafficSign extends Activity {

	ListTrafficArrayAdapter myArray;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO Auto-generated method stub
		Intent intent = getIntent();
		this.setTitle(intent.getStringExtra("catName"));
		setContentView(R.layout.activity_listtraffic);
		System.out.println("vao dc activity moi");

		ArrayList<vo.TrafficSign> arr = null;
		try {
			arr = (ArrayList<vo.TrafficSign>) ConvertUtil.bytes2Object(intent
					.getByteArrayExtra("trafficList"));
			System.out.println("Size ben nhan: " + arr.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*********************/
		final ListView lv = (ListView) findViewById(R.id.listTraffic);
		myArray = new ListTrafficArrayAdapter(this, R.layout.list_row, arr);
		lv.setAdapter(myArray);
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				View temView2 = myArray.getView(position, null, lv);
				TextView trafficName = (TextView) temView2
						.findViewById(R.id.trafficName);
				TextView trafficID = (TextView) temView2
						.findViewById(R.id.trafficID);

				// get detail from server
				String url = serviceIp + "ViewDetail?id=" + trafficID.getText();
				// System.out.println("url ne : " + url);
				HttpUtil httpUtil = new HttpUtil();
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						JSONObject objResult;
						try {
							objResult = new JSONObject(response);

							// get traffic info from respond
							vo.TrafficSign traffic = new vo.TrafficSign();
							String ID = "";
							String name = "";
							String information = "";
							String image = "";
							String penaltyfee = "";

							try {
								name = objResult.getString("ID");
							} catch (Exception e) {
								e.printStackTrace();
							}

							try {
								name = objResult.getString("name");
							} catch (Exception e) {
								e.printStackTrace();
							}

							try {
								information = objResult
										.getString("information");
							} catch (Exception e) {
								e.printStackTrace();
							}

							try {
								image = objResult.getString("image");
							} catch (Exception e) {
								e.printStackTrace();
							}

							try {
								penaltyfee = objResult.getString("penaltyfee");
							} catch (Exception e) {
								e.printStackTrace();
							}

							traffic.setTrafficID(ID);
							traffic.setTrafficName(name);
							traffic.setTrafficInfo(information);
							traffic.setTrafficImage(image);
							traffic.setTrafficPenaltyFee(penaltyfee);

							// move next screen
							Intent nextScreen = new Intent(
									getApplicationContext(),
									TracfficSignDetails.class);
							nextScreen.putExtra("trafficName", name);
							try {
								byte[] dataBytes = ConvertUtil
										.object2Bytes(traffic);
								nextScreen
										.putExtra("trafficDetails", dataBytes);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							startActivity(nextScreen);

						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}// end onComplete
				});
				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
	}

}
