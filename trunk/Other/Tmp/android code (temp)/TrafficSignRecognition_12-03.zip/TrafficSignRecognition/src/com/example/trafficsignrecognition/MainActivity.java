package com.example.trafficsignrecognition;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import static com.example.ultils.Properties.serviceIp;
import com.example.ultils.ConvertUtil;
import com.example.ultils.HttpUtil;
import com.example.ultils.JSONArrayParser;
import com.example.ultils.MyInterface.IAsyncHttpListener;
//import com.example.ultils.MyInterface.IAsyncFetchListener;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// set event for manual search button
		ImageButton imgBtnManualSearch = (ImageButton) findViewById(R.id.imageButtonManualSearch);

		imgBtnManualSearch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// parse json array
				String url = serviceIp + "GetResult";
				HttpUtil httpUtil = new HttpUtil(MainActivity.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String respond) {
						// TODO Auto-generated method stub
						JSONArray objResult;
						try {
							// get data from json respond to list
							objResult = new JSONArray(respond);
							ArrayList<vo.Category> arr = new ArrayList<vo.Category>();

							for (int i = 0; i < objResult.length(); i++) {
								vo.Category cat = new vo.Category();
								cat.setCatImage("trafficicon");
								cat.setCatName(objResult.getJSONObject(i)
										.getString("categoryName"));
								cat.setId(objResult.getJSONObject(i).getString(
										"categoryID"));
								arr.add(cat);
							}

							// Init to move to next screen
							// System.out.println("truoc khi tao intent");
							Intent nextScreen = new Intent(
									getApplicationContext(), Category.class);
							byte[] dataBytes = ConvertUtil.object2Bytes(arr);
							// System.out.println("Convert thanh cong");
							nextScreen.putExtra("catList", dataBytes);
							// System.out.println("Put thanh cong");
							// System.out.println("sau khi tao intent");
							startActivity(nextScreen);
						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
		// set event onclick for auto search button
		final ImageButton imgBtnAutoSearch = (ImageButton) findViewById(R.id.imageButtonAutoSearch);
		imgBtnAutoSearch.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// Creating the instance of PopupMenu
//				PopupMenu popup = new PopupMenu(MainActivity.this,
//						imgBtnAutoSearch);
//				// Inflating the Popup using xml file
//				popup.getMenuInflater().inflate(R.menu.popup_menu,
//						popup.getMenu());
//				popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//
//					@Override
//					public boolean onMenuItemClick(MenuItem item) {
//						// TODO Auto-generated method stub
//						//create temp variable to set type of camera (true = autocam; false = manual cam)
//						boolean typeCam =  true;
//						if (item.getTitle().toString().contains("tay")) {
//							typeCam = false;
//						}
//						Intent nextScreen = new Intent(getApplicationContext(),
//								CameraActivity.class);
//						nextScreen.putExtra("type", typeCam);
//						startActivity(nextScreen);
//						return false;
//					}
//				});
//				popup.show();
//				//
				Intent nextScreen = new Intent(getApplicationContext(),
						CameraActivity.class);
				startActivity(nextScreen);

			}
		});
		// set event onclick for auto search button
		ImageButton imgBtnHistory = (ImageButton) findViewById(R.id.imageButtonHistory);
		imgBtnHistory.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent nextScreen = new Intent(getApplicationContext(),
						ListResult.class);
				startActivity(nextScreen);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
