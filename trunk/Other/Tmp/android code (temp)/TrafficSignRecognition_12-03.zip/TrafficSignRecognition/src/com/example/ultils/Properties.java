package com.example.ultils;

public final class Properties {
	public static final String serviceIp = "http://bienbaogiaothong.tk/rest/Service/";
	public static final String serverAddress = "http://bienbaogiaothong.tk/";
	public static boolean isTaken = false;

}

