package com.example.trafficsignrecognition;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;

import com.example.ultils.ConvertUtil;
import com.example.ultils.HttpUtil;
import com.example.ultils.MyInterface.IAsyncHttpListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;
import static com.example.ultils.Properties.serviceIp;

public class Category extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category);
		Intent intent = getIntent();
		ArrayList<vo.Category> arr = null;
		try {
			arr = (ArrayList<vo.Category>) ConvertUtil.bytes2Object(intent
					.getByteArrayExtra("catList"));
			System.out.println("Size: " + arr.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final ListView lv = (ListView) findViewById(R.id.listCategory);
		MyArrayAdapter myArray = new MyArrayAdapter(this, R.layout.list_rowcat,
				arr);
		lv.setAdapter(myArray);
		//
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				/**************/
				View tempView = lv.getChildAt(position);
				TextView textview = (TextView) tempView
						.findViewById(R.id.trafficName);
				TextView catID = (TextView) tempView
						.findViewById(R.id.trafficID);
				Intent nextScreen = new Intent(getApplicationContext(),
						ListTrafficSign.class);

				nextScreen.putExtra("catName", textview.getText());
				/*************/
				// parse json array
				String url = serviceIp + "SearchByID?id=" + catID.getText();
				HttpUtil httpUtil = new HttpUtil(Category.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						// get data from json array to list
						JSONArray objResult;
						ArrayList<vo.TrafficSign> arr = new ArrayList<vo.TrafficSign>();
						try {
							objResult = new JSONArray(response);
							for (int i = 0; i < objResult.length(); i++) {
								vo.TrafficSign traffic = new vo.TrafficSign();
								traffic.setTrafficID(objResult.getJSONObject(i)
										.getString("trafficID"));
								traffic.setTrafficName(objResult.getJSONObject(
										i).getString("name"));
								traffic.setTrafficImage("cam_di_nguoc_chieu");
								arr.add(traffic);
							}// end for

							Intent nextScreen = new Intent(
									getApplicationContext(),
									ListTrafficSign.class);
							byte[] dataBytes = ConvertUtil.object2Bytes(arr);
							// System.out.println("Convert thanh cong");
							nextScreen.putExtra("trafficList", dataBytes);
							// System.out.println("Put thanh cong");
							nextScreen
									.putExtra("catName", "Danh sach bien bao");
							startActivity(nextScreen);
						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}// end onComplete
				});
				httpUtil.setUrl(url);
				httpUtil.execute();
				/*************/

			}
		});
		//
		ImageButton btnSearch = (ImageButton) findViewById(R.id.searchButton);
		btnSearch.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View V) {
				// TODO Auto-generated method stub
				// parse json array
				EditText searchKey = (EditText) findViewById(R.id.searchTraffic);
				String url = serviceIp + "SearchByName?name="
						+ searchKey.getText();
				HttpUtil httpUtil = new HttpUtil(Category.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						JSONArray objResult;
						try {
							objResult = new JSONArray(response);
							ArrayList<vo.TrafficSign> arr = new ArrayList<vo.TrafficSign>();
							System.out.println("Length result traffic: "
									+ objResult.length());
							for (int i = 0; i < objResult.length(); i++) {
								vo.TrafficSign traffic = new vo.TrafficSign();
								traffic.setTrafficID(objResult.getJSONObject(i)
										.getString("trafficID"));
								traffic.setTrafficName(objResult.getJSONObject(
										i).getString("name"));
								traffic.setTrafficImage("cam_di_nguoc_chieu");
								arr.add(traffic);
							}
							
							// move to next screen
							Intent nextScreen = new Intent(
									getApplicationContext(),
									ListTrafficSign.class);
							byte[] dataBytes = ConvertUtil.object2Bytes(arr);
							nextScreen.putExtra("trafficList", dataBytes);
							nextScreen.putExtra("catName", "Kết quả tìm kiếm");
							startActivity(nextScreen);
						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				});
				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
		// TODO Auto-generated method stub
	}
}
