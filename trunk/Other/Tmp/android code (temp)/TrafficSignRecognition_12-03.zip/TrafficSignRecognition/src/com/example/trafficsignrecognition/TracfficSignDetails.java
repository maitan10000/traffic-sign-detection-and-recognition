package com.example.trafficsignrecognition;

import static com.example.ultils.Properties.serverAddress;

import java.io.IOException;
import com.example.ultils.ConvertUtil;
import com.example.ultils.ImageUtils;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TracfficSignDetails extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_traffic_sign_detail);
		Intent intent = getIntent();
		this.setTitle(intent.getStringExtra("trafficName"));
		// lay du lieu
		System.out.println("vao dc view details");
		vo.TrafficSign trafficInfo = null;
		try {
			trafficInfo = (vo.TrafficSign) ConvertUtil.bytes2Object(intent
					.getByteArrayExtra("trafficDetails"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Set traffic sign detail to view
		if (trafficInfo != null) {
			ImageView image = (ImageView) findViewById(R.id.trafficImage);
			TextView name = (TextView) findViewById(R.id.trafficName);
			TextView info = (TextView) findViewById(R.id.trafficContent);
			TextView penaltyFee = (TextView) findViewById(R.id.trafficPenaltyFee);
			TextView id = (TextView) findViewById(R.id.trafficID);
			// //
			name.setText(trafficInfo.getTrafficName());
			info.setText(trafficInfo.getTrafficInfo());
			penaltyFee.setText(trafficInfo.getTrafficPenaltyFee());
			id.setText(trafficInfo.getTrafficID());
			// set image
			if (trafficInfo.getTrafficImage() != null) {
				String imageUrl = serverAddress + trafficInfo.getTrafficImage();
				Bitmap imageTmp = ImageUtils.convertUrlToBitmap(imageUrl);
				image.setImageBitmap(imageTmp);
			}

		} else {
			// handle null;
			Toast.makeText(getApplicationContext(),
					"Khong co thong tin traffic sign", Toast.LENGTH_LONG);
		}
		// iamge
		// View view = new View(getApplicationContext());
		// String uri_icon = "drawable/" + trafficInfo.getTrafficImage();
		// int ImageResource =
		// view.getContext().getResources().getIdentifier(uri_icon, null,
		// view.getContext().getApplicationContext().getPackageName());
		// Drawable img =
		// view.getContext().getResources().getDrawable(ImageResource);
		// image.setImageDrawable(img);
	}
}
