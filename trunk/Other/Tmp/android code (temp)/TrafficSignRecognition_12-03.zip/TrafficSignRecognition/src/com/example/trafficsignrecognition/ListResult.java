package com.example.trafficsignrecognition;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vo.ResultInput;
import vo.TrafficSign;

import com.example.ultils.ConvertUtil;
import com.example.ultils.HttpImageUtils;
import com.example.ultils.HttpUtil;
import com.example.ultils.ImageUtils;
import com.example.ultils.MyInterface.IAsyncHttpImageListener;
import com.example.ultils.MyInterface.IAsyncHttpListener;

import static com.example.ultils.Properties.serviceIp;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;
import static com.example.ultils.Properties.serverAddress;

public class ListResult extends Activity {

	ListResultArrayAdapter myArray;
	static ArrayList<vo.ResultInput> arr2;
	static ListView lv;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO Auto-generated method stub
		setContentView(R.layout.activity_result);
		Intent intent = getIntent();
		String imagePath = intent.getStringExtra("imagePath");
		// Data fix cung de test
		ArrayList<vo.ResultInput> arr = new ArrayList<ResultInput>();
		ResultInput test = new ResultInput();
		test.setTrafficID("ID001");
		test.setTrafficImage("cam_di_nguoc_chieu");
		test.setTrafficName("cam di nguoc chieu");
		arr.add(test);
		arr.add(test);
		arr.add(test);
		arr.add(test);
		arr.add(test);
		arr.add(test);
		arr.add(test);
		arr.add(test);
		//
		// Get list from extra
		// ArrayList<vo.ResultInput> arr2 = null;
		try {
			arr2 = (ArrayList<vo.ResultInput>) ConvertUtil.bytes2Object(intent
					.getByteArrayExtra("listResult"));
			System.out.println("Size: " + arr2.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ///
		lv = (ListView) findViewById(R.id.listResult);
		myArray = new ListResultArrayAdapter(this, R.layout.list_row, arr2);
		lv.setAdapter(myArray);
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) {
				View temView2 = myArray.getView(position, null, lv);
				// TextView trafficName = (TextView) temView2
				// .findViewById(R.id.trafficName);
				TextView trafficID = (TextView) temView2
						.findViewById(R.id.trafficID);
				String url = serviceIp + "ViewDetail?id=" + trafficID.getText();

				HttpUtil httpUtil = new HttpUtil(ListResult.this);
				httpUtil.setHttpListener(new IAsyncHttpListener() {
					@Override
					public void onComplete(String response) {
						// TODO Auto-generated method stub
						JSONObject objResult;
						try {
							objResult = new JSONObject(response);

							// get data from json array to list
							String title = "";
							vo.TrafficSign traffic = new vo.TrafficSign();
							traffic.setTrafficName(objResult.getString("name"));
							traffic.setTrafficInfo(objResult
									.getString("information"));
							traffic.setTrafficImage("cam_di_nguoc_chieu");
							traffic.setTrafficPenaltyFee(objResult
									.getString("penaltyfee"));
							title = objResult.getString("name");

							// move to next screen
							Intent nextScreen = new Intent(
									getApplicationContext(),
									TracfficSignDetails.class);
							nextScreen.putExtra("trafficName", title);
							byte[] dataBytes = ConvertUtil
									.object2Bytes(traffic);
							nextScreen.putExtra("trafficDetails", dataBytes);
							startActivity(nextScreen);
						} catch (JSONException e) {
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}// end onComplete
				});

				httpUtil.setUrl(url);
				httpUtil.execute();
			}
		});
		ImageView resultImage = (ImageView) findViewById(R.id.imageResult);
		// String imagePath = "/mnt/sdcard/test.jpg";
		Bitmap image = ImageUtils.drawImage(imagePath, arr2);
		resultImage.setImageBitmap(image);

		//
		Button btn = (Button) findViewById(R.id.btnTest);
		btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				// display image
				for (int i = 0; i < arr2.size(); i++) {
					int wantedPosition = i;
					if (arr2.get(wantedPosition).getTrafficID().length() > 0) {
						HttpImageUtils httpImgUtil = new HttpImageUtils();
						httpImgUtil.setUrl(serverAddress
								+ arr2.get(wantedPosition).getTrafficImage());
						httpImgUtil.setExtra(wantedPosition);
						httpImgUtil
								.setHttpImageListener(new IAsyncHttpImageListener() {

									@Override
									public void onComplete(Bitmap bitmap,
											int extra) {
										// Bitmap tempBit = null;
										View tmpView = lv.getChildAt(extra);// myArray.getView(0,
																			// null,
																			// lv);
										ImageView icon = (ImageView) tmpView
												.findViewById(R.id.trafficImage);
										icon.setImageBitmap(bitmap);
									}
								});
						httpImgUtil.execute();
					}// end if length > 0
				}// end for

			}
		});
	}

	// @Override
	// protected void onResume() {
	// //Toast.makeText(getApplicationContext(), "OnResume",
	// Toast.LENGTH_SHORT);
	// // display image
	// // for (int i = 0; i < arr2.size(); i++) {
	// // int wantedPosition = i;
	// // if (arr2.get(wantedPosition).getTrafficID().length() > 0) {
	// // HttpImageUtils httpImgUtil = new HttpImageUtils();
	// // httpImgUtil.setUrl(serverAddress
	// // + arr2.get(wantedPosition).getTrafficImage());
	// // httpImgUtil.setExtra(wantedPosition);
	// // httpImgUtil.setHttpImageListener(new IAsyncHttpImageListener() {
	// //
	// // @Override
	// // public void onComplete(Bitmap bitmap, int extra) {
	// // // Bitmap tempBit = null;
	// // View tmpView = lv.getChildAt(extra);// myArray.getView(0,
	// // // null,
	// // // lv);
	// // ImageView icon = (ImageView) tmpView
	// // .findViewById(R.id.trafficImage);
	// // icon.setImageBitmap(bitmap);
	// // }
	// // });
	// // httpImgUtil.execute();
	// // }// end if length > 0
	// // }// end for
	// }
}
