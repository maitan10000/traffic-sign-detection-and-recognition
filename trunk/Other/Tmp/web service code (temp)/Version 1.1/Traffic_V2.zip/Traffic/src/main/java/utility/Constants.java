package utility;

public class Constants {
	
}
