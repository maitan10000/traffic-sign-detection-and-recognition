package dto;

public class TrainImageDTO {
	private String trafficID;
	private String imageID;
	private String imageName;

	public TrainImageDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getTrafficID() {
		return trafficID;
	}

	public void setTrafficID(String trafficID) {
		this.trafficID = trafficID;
	}

	public String getImageID() {
		return imageID;
	}

	public void setImageID(String imageID) {
		this.imageID = imageID;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

}
