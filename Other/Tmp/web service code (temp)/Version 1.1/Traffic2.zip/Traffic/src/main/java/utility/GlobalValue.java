package utility;

public class GlobalValue {
	public static String WorkPath = "";
}
