package dto;

public class AccountJSON {

}
